module.exports = {
  tokens: "7970383191:AAGxjyWnYGCLlcEFe6vs2tYtpztAIVtdsh4", 
  owner: "7615520596", 
  port: "2105", // Ini Wajib Jangan Diubah
  ipvps: "http://fyzz.ganteng.lightsecretconnected.my.id" // Jangan Diubah Nanti Eror!!
};